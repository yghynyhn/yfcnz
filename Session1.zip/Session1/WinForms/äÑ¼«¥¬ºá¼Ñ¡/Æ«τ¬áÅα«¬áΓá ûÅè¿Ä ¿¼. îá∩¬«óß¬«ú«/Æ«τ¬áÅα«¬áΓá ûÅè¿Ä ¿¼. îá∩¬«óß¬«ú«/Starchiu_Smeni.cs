﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;
using System.IO;

namespace ТочкаПроката_ЦПКиО_им.Маяковского
{
    public partial class Starchiu_Smeni : Form
    {
        public Starchiu_Smeni()
        {
            InitializeComponent();
            con = new SqlConnection(@"Data source = KYPAMA\KYPAMA; initial catalog = Прокат; Integrated security = SSPI;");
        }

        DataTable table = new DataTable();
        public int codestaff;
        SqlConnection con;

        private void na_glavnuy_Click(object sender, EventArgs e)
        {
            Avtorizatchia avtorizatchia = new Avtorizatchia();
            vremya.Stop();
            avtorizatchia.Show();
            Hide();
        }

        private void Starchiu_Smeni_Load(object sender, EventArgs e)
        {
            //Считывание данных о пользователе
            con.Open();
            string select = @"SELECT [Role],[LastName],[FirstName],[Patronymic],[Photo] FROM [dbo].[Staff] ";
            string where = "Where [CodeStaff] = '" + codestaff + "'";
            string search = select + where;
            SqlCommand com = new SqlCommand(search, con);

            SqlDataReader reader = com.ExecuteReader();
            table.Load(reader);
            con.Close();

            //Фото из базы
            byte[] bytes = (byte[])table.Rows[0].ItemArray[4];
            MemoryStream ms = new MemoryStream(bytes);
            photo_profile.Image = Image.FromStream(ms);

            //ФИО из базы
            string fio = table.Rows[0].ItemArray[1].ToString() + " " + table.Rows[0].ItemArray[2].ToString() + " " + table.Rows[0].ItemArray[3].ToString();
            fio_profile.Text = fio;

            //Роль из базы
            role.Text = table.Rows[0].ItemArray[0].ToString();
        }

        private void Starchiu_Smeni_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void oformlenie_zakaza_Click(object sender, EventArgs e)
        {

        }
        int minutes = 0;
        int chas = 0;
        int minut = 0;

        private void vremya_Tick(object sender, EventArgs e)
        {
            minutes++;
            if (minut < 60)
            {
                minut++;
            }
            else
            {
                chas++;
                minut = 0;
            }
            if (minutes >= 10 && chas >= 0)
            {
                vremya.Stop();
                Avtorizatchia avtorizatchia = new Avtorizatchia();
                avtorizatchia.vhod.Enabled = false;
                avtorizatchia.vremya.Start();
                avtorizatchia.Show();
                Hide();
            }
            if (minutes == 5 && chas >= 0)
            {
                MessageBox.Show("Осталось 5 минут");
            }
            chasi.Text = chas.ToString() + " : " + minut.ToString();
        }

      
    }
}
