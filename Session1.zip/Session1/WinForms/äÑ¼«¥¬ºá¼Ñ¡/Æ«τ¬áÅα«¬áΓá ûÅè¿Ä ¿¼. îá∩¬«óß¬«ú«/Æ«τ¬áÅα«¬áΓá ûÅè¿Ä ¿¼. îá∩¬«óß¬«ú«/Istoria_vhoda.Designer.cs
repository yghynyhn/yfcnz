﻿namespace ТочкаПроката_ЦПКиО_им.Маяковского
{
    partial class Istoria_vhoda
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Istoria_vhoda));
            this.tablitsa_istoria = new System.Windows.Forms.DataGridView();
            this.naimenovanie_form = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.shapka = new System.Windows.Forms.PictureBox();
            this.obnovit = new System.Windows.Forms.Button();
            this.filtr_po_loginy = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.filtr_po_date = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.tablitsa_istoria)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shapka)).BeginInit();
            this.SuspendLayout();
            // 
            // tablitsa_istoria
            // 
            this.tablitsa_istoria.BackgroundColor = System.Drawing.Color.White;
            this.tablitsa_istoria.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tablitsa_istoria.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tablitsa_istoria.Location = new System.Drawing.Point(13, 85);
            this.tablitsa_istoria.Name = "tablitsa_istoria";
            this.tablitsa_istoria.Size = new System.Drawing.Size(355, 353);
            this.tablitsa_istoria.TabIndex = 0;
            // 
            // naimenovanie_form
            // 
            this.naimenovanie_form.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.naimenovanie_form.AutoSize = true;
            this.naimenovanie_form.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(118)))), ((int)(((byte)(227)))), ((int)(((byte)(131)))));
            this.naimenovanie_form.Font = new System.Drawing.Font("Comic Sans MS", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.naimenovanie_form.Location = new System.Drawing.Point(84, 18);
            this.naimenovanie_form.Name = "naimenovanie_form";
            this.naimenovanie_form.Size = new System.Drawing.Size(246, 45);
            this.naimenovanie_form.TabIndex = 19;
            this.naimenovanie_form.Text = "История входа";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(118)))), ((int)(((byte)(227)))), ((int)(((byte)(131)))));
            this.pictureBox1.Image = global::ТочкаПроката_ЦПКиО_им.Маяковского.Properties.Resources.logo1;
            this.pictureBox1.Location = new System.Drawing.Point(10, 6);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(64, 64);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 18;
            this.pictureBox1.TabStop = false;
            // 
            // shapka
            // 
            this.shapka.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(118)))), ((int)(((byte)(227)))), ((int)(((byte)(131)))));
            this.shapka.Location = new System.Drawing.Point(-6, -15);
            this.shapka.Name = "shapka";
            this.shapka.Size = new System.Drawing.Size(806, 88);
            this.shapka.TabIndex = 20;
            this.shapka.TabStop = false;
            // 
            // obnovit
            // 
            this.obnovit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(118)))), ((int)(((byte)(227)))), ((int)(((byte)(131)))));
            this.obnovit.FlatAppearance.BorderSize = 0;
            this.obnovit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.obnovit.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.obnovit.Location = new System.Drawing.Point(386, 85);
            this.obnovit.Name = "obnovit";
            this.obnovit.Size = new System.Drawing.Size(118, 53);
            this.obnovit.TabIndex = 21;
            this.obnovit.Text = "Обновить";
            this.obnovit.UseVisualStyleBackColor = false;
            this.obnovit.Click += new System.EventHandler(this.obnovit_Click);
            // 
            // filtr_po_loginy
            // 
            this.filtr_po_loginy.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.filtr_po_loginy.Location = new System.Drawing.Point(386, 192);
            this.filtr_po_loginy.Name = "filtr_po_loginy";
            this.filtr_po_loginy.Size = new System.Drawing.Size(118, 23);
            this.filtr_po_loginy.TabIndex = 22;
            this.filtr_po_loginy.TextChanged += new System.EventHandler(this.filtr_po_loginy_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(392, 157);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 23);
            this.label1.TabIndex = 23;
            this.label1.Text = "Логин";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(392, 238);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(94, 23);
            this.label2.TabIndex = 25;
            this.label2.Text = "Дата входа";
            // 
            // filtr_po_date
            // 
            this.filtr_po_date.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.filtr_po_date.Location = new System.Drawing.Point(385, 275);
            this.filtr_po_date.Name = "filtr_po_date";
            this.filtr_po_date.Size = new System.Drawing.Size(121, 23);
            this.filtr_po_date.TabIndex = 26;
            this.filtr_po_date.ValueChanged += new System.EventHandler(this.filtr_po_date_ValueChanged);
            // 
            // Istoria_vhoda
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(518, 450);
            this.Controls.Add(this.filtr_po_date);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.filtr_po_loginy);
            this.Controls.Add(this.obnovit);
            this.Controls.Add(this.naimenovanie_form);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.shapka);
            this.Controls.Add(this.tablitsa_istoria);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Istoria_vhoda";
            this.Text = "История входа";
            ((System.ComponentModel.ISupportInitialize)(this.tablitsa_istoria)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shapka)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView tablitsa_istoria;
        private System.Windows.Forms.Label naimenovanie_form;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox shapka;
        private System.Windows.Forms.Button obnovit;
        private System.Windows.Forms.TextBox filtr_po_loginy;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker filtr_po_date;
    }
}