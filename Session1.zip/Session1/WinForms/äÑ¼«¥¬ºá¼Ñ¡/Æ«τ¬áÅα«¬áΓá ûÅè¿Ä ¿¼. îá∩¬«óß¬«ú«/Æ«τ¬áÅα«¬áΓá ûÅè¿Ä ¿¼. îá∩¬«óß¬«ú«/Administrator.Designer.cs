﻿namespace ТочкаПроката_ЦПКиО_им.Маяковского
{
    partial class Administrator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Administrator));
            this.na_glavnuy = new System.Windows.Forms.Button();
            this.role = new System.Windows.Forms.Label();
            this.fio_profile = new System.Windows.Forms.Label();
            this.vremya = new System.Windows.Forms.Timer(this.components);
            this.chasi = new System.Windows.Forms.Label();
            this.istoria = new System.Windows.Forms.Button();
            this.photo_profile = new System.Windows.Forms.PictureBox();
            this.naimenovanie_form = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.shapka = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.photo_profile)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shapka)).BeginInit();
            this.SuspendLayout();
            // 
            // na_glavnuy
            // 
            this.na_glavnuy.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(118)))), ((int)(((byte)(227)))), ((int)(((byte)(131)))));
            this.na_glavnuy.FlatAppearance.BorderSize = 0;
            this.na_glavnuy.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.na_glavnuy.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.na_glavnuy.Location = new System.Drawing.Point(649, 191);
            this.na_glavnuy.Name = "na_glavnuy";
            this.na_glavnuy.Size = new System.Drawing.Size(129, 80);
            this.na_glavnuy.TabIndex = 10;
            this.na_glavnuy.Text = "На главную форму";
            this.na_glavnuy.UseVisualStyleBackColor = false;
            this.na_glavnuy.Click += new System.EventHandler(this.na_glavnuy_Click);
            // 
            // role
            // 
            this.role.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.role.AutoSize = true;
            this.role.Font = new System.Drawing.Font("Comic Sans MS", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.role.Location = new System.Drawing.Point(222, 141);
            this.role.Name = "role";
            this.role.Size = new System.Drawing.Size(70, 33);
            this.role.TabIndex = 9;
            this.role.Text = "Роль";
            // 
            // fio_profile
            // 
            this.fio_profile.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.fio_profile.AutoSize = true;
            this.fio_profile.Font = new System.Drawing.Font("Comic Sans MS", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.fio_profile.Location = new System.Drawing.Point(222, 86);
            this.fio_profile.Name = "fio_profile";
            this.fio_profile.Size = new System.Drawing.Size(81, 40);
            this.fio_profile.TabIndex = 8;
            this.fio_profile.Text = "ФИО";
            // 
            // vremya
            // 
            this.vremya.Tick += new System.EventHandler(this.vremya_Tick);
            // 
            // chasi
            // 
            this.chasi.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chasi.AutoSize = true;
            this.chasi.Font = new System.Drawing.Font("Comic Sans MS", 20.25F);
            this.chasi.Location = new System.Drawing.Point(705, 88);
            this.chasi.Name = "chasi";
            this.chasi.Size = new System.Drawing.Size(73, 38);
            this.chasi.TabIndex = 11;
            this.chasi.Text = "0 : 0";
            // 
            // istoria
            // 
            this.istoria.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(118)))), ((int)(((byte)(227)))), ((int)(((byte)(131)))));
            this.istoria.FlatAppearance.BorderSize = 0;
            this.istoria.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.istoria.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.istoria.Location = new System.Drawing.Point(229, 191);
            this.istoria.Name = "istoria";
            this.istoria.Size = new System.Drawing.Size(129, 80);
            this.istoria.TabIndex = 12;
            this.istoria.Text = "Проcмотр истории входа";
            this.istoria.UseVisualStyleBackColor = false;
            this.istoria.Click += new System.EventHandler(this.istoria_Click);
            // 
            // photo_profile
            // 
            this.photo_profile.Location = new System.Drawing.Point(12, 73);
            this.photo_profile.Name = "photo_profile";
            this.photo_profile.Size = new System.Drawing.Size(189, 198);
            this.photo_profile.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.photo_profile.TabIndex = 7;
            this.photo_profile.TabStop = false;
            // 
            // naimenovanie_form
            // 
            this.naimenovanie_form.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.naimenovanie_form.AutoSize = true;
            this.naimenovanie_form.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(118)))), ((int)(((byte)(227)))), ((int)(((byte)(131)))));
            this.naimenovanie_form.Font = new System.Drawing.Font("Comic Sans MS", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.naimenovanie_form.Location = new System.Drawing.Point(85, 14);
            this.naimenovanie_form.Name = "naimenovanie_form";
            this.naimenovanie_form.Size = new System.Drawing.Size(259, 45);
            this.naimenovanie_form.TabIndex = 16;
            this.naimenovanie_form.Text = "Администратор";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(118)))), ((int)(((byte)(227)))), ((int)(((byte)(131)))));
            this.pictureBox1.Image = global::ТочкаПроката_ЦПКиО_им.Маяковского.Properties.Resources.logo1;
            this.pictureBox1.Location = new System.Drawing.Point(13, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(64, 64);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 15;
            this.pictureBox1.TabStop = false;
            // 
            // shapka
            // 
            this.shapka.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(118)))), ((int)(((byte)(227)))), ((int)(((byte)(131)))));
            this.shapka.Location = new System.Drawing.Point(-3, -19);
            this.shapka.Name = "shapka";
            this.shapka.Size = new System.Drawing.Size(806, 88);
            this.shapka.TabIndex = 17;
            this.shapka.TabStop = false;
            // 
            // Administrator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(790, 283);
            this.Controls.Add(this.naimenovanie_form);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.shapka);
            this.Controls.Add(this.istoria);
            this.Controls.Add(this.chasi);
            this.Controls.Add(this.na_glavnuy);
            this.Controls.Add(this.role);
            this.Controls.Add(this.fio_profile);
            this.Controls.Add(this.photo_profile);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Administrator";
            this.Text = "Администратор";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Administrator_FormClosed);
            this.Load += new System.EventHandler(this.Administrator_Load);
            ((System.ComponentModel.ISupportInitialize)(this.photo_profile)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shapka)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button na_glavnuy;
        private System.Windows.Forms.Label role;
        private System.Windows.Forms.Label fio_profile;
        private System.Windows.Forms.PictureBox photo_profile;
        private System.Windows.Forms.Timer vremya;
        private System.Windows.Forms.Label chasi;
        private System.Windows.Forms.Button istoria;
        private System.Windows.Forms.Label naimenovanie_form;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox shapka;
    }
}