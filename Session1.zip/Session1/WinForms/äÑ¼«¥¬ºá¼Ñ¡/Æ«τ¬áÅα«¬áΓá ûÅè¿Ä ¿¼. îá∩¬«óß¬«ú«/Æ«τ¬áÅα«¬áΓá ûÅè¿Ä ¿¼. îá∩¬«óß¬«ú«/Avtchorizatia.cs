﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;

namespace ТочкаПроката_ЦПКиО_им.Маяковского
{
    public partial class Avtorizatchia : Form
    {
        public Avtorizatchia()
        {
            InitializeComponent();
            //На демо экзамнене строка в скобках будет (@"Data source = ip_сервера; initial catalog = ваша_бд; User id = Ваш_логин; Password = Ваш_пароль")
            con = new SqlConnection(@"Data source = KYPAMA\KYPAMA; initial catalog = Прокат; Integrated security = SSPI;");
            vremya.Interval = 60000;
            
            

        }
        int oshibok=0;
        SqlConnection con;
        private void vhod_Click(object sender, EventArgs e)
        {
            //Забор из базы данных сотрудников вместе с их должностями
            con.Open();
            string select = @"SELECT [CodeStaff],[Role] FROM [dbo].[Staff] ";
            string where = "Where [Login] = '" + login.Text + "' and [Password] = '" + password.Text +"'";
            string search = select + where;
            SqlCommand com = new SqlCommand(search,con);
            DataTable table = new DataTable();
            SqlDataReader reader = com.ExecuteReader();
            table.Load(reader);
            con.Close();

            try
            {
                //Проверка и переход на другие формы
                if (table.Rows[0].ItemArray[1].ToString() == "Продавец")
                {
                    Prodavets prodavets = new Prodavets();
                    prodavets.codestaff = Convert.ToInt32(table.Rows[0].ItemArray[0].ToString());
                    prodavets.Show();
                    Hide();
                }
                if (table.Rows[0].ItemArray[1].ToString() == "Администратор")
                {
                    Administrator administrator = new Administrator();
                    administrator.codestaff = Convert.ToInt32(table.Rows[0].ItemArray[0].ToString());
                    administrator.Show();
                    Hide();
                }
                if (table.Rows[0].ItemArray[1].ToString() == "Старший смены")
                {
                    Starchiu_Smeni starchiu = new Starchiu_Smeni();
                    starchiu.codestaff = Convert.ToInt32(table.Rows[0].ItemArray[0].ToString());
                    starchiu.Show();
                    Hide();
                }
            }
            catch
            {
                if (oshibok >= 1)
                {
                    MessageBox.Show("Неверный Логин или Пароль!\nПопыток осталось 0");
                    vhod.Enabled = false;
                    vremya.Start();
                }
                if (oshibok == 0)
                {
                    MessageBox.Show("Неверный Логин или Пароль!\nПопыток осталось 1");
                    oshibok++;
                }
                else
                {
                    oshibok = 0;
                }
                
            }
        }

        private void Avtorizatchia_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void password_view_CheckedChanged(object sender, EventArgs e)
        {
            if (password_view.Checked == true)
            {
                password.UseSystemPasswordChar = false;
            }
            else
            {
                password.UseSystemPasswordChar = true;
            }
        }

        //Для разработки
        private void razrabotka1_Click(object sender, EventArgs e)
        {
            login.Text = "Ivanov@namecomp.ru";
            password.Text = "2L6KZG";
        }

        private void razrabotka2_Click(object sender, EventArgs e)
        {
            login.Text = "fedorov@namecomp.ru";
            password.Text = "8ntwUp";
        }

        private void razrabotka3_Click(object sender, EventArgs e)
        {
            login.Text = "mironov@namecomp.ru";
            password.Text = "YOyhfR";
        }
        int minut = 0;
        private void vremua_Tick(object sender, EventArgs e)
        {
            minut++;
            if (minut >= 3)
            {
                vhod.Enabled = true;
            }
            vremya.Stop();
        }
    }
}
