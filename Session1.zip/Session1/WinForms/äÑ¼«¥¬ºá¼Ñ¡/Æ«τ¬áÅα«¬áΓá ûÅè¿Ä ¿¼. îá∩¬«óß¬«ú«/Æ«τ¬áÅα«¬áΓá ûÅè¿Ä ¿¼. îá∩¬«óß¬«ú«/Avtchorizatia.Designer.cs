﻿namespace ТочкаПроката_ЦПКиО_им.Маяковского
{
    partial class Avtorizatchia
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Avtorizatchia));
            this.login = new System.Windows.Forms.TextBox();
            this.password = new System.Windows.Forms.TextBox();
            this.Avtorizatia = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.vhod = new System.Windows.Forms.Button();
            this.password_view = new System.Windows.Forms.CheckBox();
            this.razrabotka1 = new System.Windows.Forms.Button();
            this.razrabotka2 = new System.Windows.Forms.Button();
            this.razrabotka3 = new System.Windows.Forms.Button();
            this.vremya = new System.Windows.Forms.Timer(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.shapka = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shapka)).BeginInit();
            this.SuspendLayout();
            // 
            // login
            // 
            this.login.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.login.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.login.Location = new System.Drawing.Point(41, 150);
            this.login.Name = "login";
            this.login.Size = new System.Drawing.Size(234, 23);
            this.login.TabIndex = 0;
            // 
            // password
            // 
            this.password.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.password.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.password.Location = new System.Drawing.Point(41, 269);
            this.password.Name = "password";
            this.password.Size = new System.Drawing.Size(234, 23);
            this.password.TabIndex = 1;
            this.password.UseSystemPasswordChar = true;
            // 
            // Avtorizatia
            // 
            this.Avtorizatia.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Avtorizatia.AutoSize = true;
            this.Avtorizatia.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(118)))), ((int)(((byte)(227)))), ((int)(((byte)(131)))));
            this.Avtorizatia.Font = new System.Drawing.Font("Comic Sans MS", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Avtorizatia.Location = new System.Drawing.Point(73, 33);
            this.Avtorizatia.Name = "Avtorizatia";
            this.Avtorizatia.Size = new System.Drawing.Size(185, 38);
            this.Avtorizatia.TabIndex = 2;
            this.Avtorizatia.Text = "Авторизация";
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(121, 102);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 29);
            this.label1.TabIndex = 3;
            this.label1.Text = "Логин";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Comic Sans MS", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(115, 223);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 29);
            this.label2.TabIndex = 4;
            this.label2.Text = "Пароль";
            // 
            // vhod
            // 
            this.vhod.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(118)))), ((int)(((byte)(227)))), ((int)(((byte)(131)))));
            this.vhod.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(140)))), ((int)(((byte)(81)))));
            this.vhod.FlatAppearance.BorderSize = 0;
            this.vhod.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.vhod.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.vhod.Location = new System.Drawing.Point(114, 314);
            this.vhod.Name = "vhod";
            this.vhod.Size = new System.Drawing.Size(90, 44);
            this.vhod.TabIndex = 5;
            this.vhod.Text = "Вход";
            this.vhod.UseVisualStyleBackColor = false;
            this.vhod.Click += new System.EventHandler(this.vhod_Click);
            // 
            // password_view
            // 
            this.password_view.AutoSize = true;
            this.password_view.Location = new System.Drawing.Point(281, 272);
            this.password_view.Name = "password_view";
            this.password_view.Size = new System.Drawing.Size(15, 14);
            this.password_view.TabIndex = 7;
            this.password_view.UseVisualStyleBackColor = true;
            this.password_view.CheckedChanged += new System.EventHandler(this.password_view_CheckedChanged);
            // 
            // razrabotka1
            // 
            this.razrabotka1.Location = new System.Drawing.Point(302, 309);
            this.razrabotka1.Name = "razrabotka1";
            this.razrabotka1.Size = new System.Drawing.Size(10, 10);
            this.razrabotka1.TabIndex = 8;
            this.razrabotka1.Text = "Вход";
            this.razrabotka1.UseVisualStyleBackColor = true;
            this.razrabotka1.Click += new System.EventHandler(this.razrabotka1_Click);
            // 
            // razrabotka2
            // 
            this.razrabotka2.Location = new System.Drawing.Point(302, 326);
            this.razrabotka2.Name = "razrabotka2";
            this.razrabotka2.Size = new System.Drawing.Size(10, 10);
            this.razrabotka2.TabIndex = 9;
            this.razrabotka2.Text = "Вход";
            this.razrabotka2.UseVisualStyleBackColor = true;
            this.razrabotka2.Click += new System.EventHandler(this.razrabotka2_Click);
            // 
            // razrabotka3
            // 
            this.razrabotka3.Location = new System.Drawing.Point(302, 342);
            this.razrabotka3.Name = "razrabotka3";
            this.razrabotka3.Size = new System.Drawing.Size(10, 10);
            this.razrabotka3.TabIndex = 10;
            this.razrabotka3.Text = "Вход";
            this.razrabotka3.UseVisualStyleBackColor = true;
            this.razrabotka3.Click += new System.EventHandler(this.razrabotka3_Click);
            // 
            // vremya
            // 
            this.vremya.Tick += new System.EventHandler(this.vremua_Tick);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(118)))), ((int)(((byte)(227)))), ((int)(((byte)(131)))));
            this.pictureBox1.Image = global::ТочкаПроката_ЦПКиО_им.Маяковского.Properties.Resources.logo1;
            this.pictureBox1.Location = new System.Drawing.Point(3, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(64, 64);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // shapka
            // 
            this.shapka.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(118)))), ((int)(((byte)(227)))), ((int)(((byte)(131)))));
            this.shapka.Location = new System.Drawing.Point(-150, -2);
            this.shapka.Name = "shapka";
            this.shapka.Size = new System.Drawing.Size(806, 88);
            this.shapka.TabIndex = 15;
            this.shapka.TabStop = false;
            // 
            // Avtorizatchia
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(324, 382);
            this.Controls.Add(this.razrabotka3);
            this.Controls.Add(this.razrabotka2);
            this.Controls.Add(this.razrabotka1);
            this.Controls.Add(this.password_view);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.vhod);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Avtorizatia);
            this.Controls.Add(this.password);
            this.Controls.Add(this.login);
            this.Controls.Add(this.shapka);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Avtorizatchia";
            this.Text = "Авторизация";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Avtorizatchia_FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shapka)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox login;
        private System.Windows.Forms.TextBox password;
        private System.Windows.Forms.Label Avtorizatia;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.CheckBox password_view;
        private System.Windows.Forms.Button razrabotka1;
        private System.Windows.Forms.Button razrabotka2;
        private System.Windows.Forms.Button razrabotka3;
        public System.Windows.Forms.Button vhod;
        public System.Windows.Forms.Timer vremya;
        private System.Windows.Forms.PictureBox shapka;
    }
}

