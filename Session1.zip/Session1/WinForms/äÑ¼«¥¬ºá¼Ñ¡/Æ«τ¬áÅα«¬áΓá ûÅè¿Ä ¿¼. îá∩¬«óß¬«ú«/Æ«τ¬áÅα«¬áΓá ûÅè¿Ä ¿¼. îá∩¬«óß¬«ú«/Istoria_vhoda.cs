﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;

namespace ТочкаПроката_ЦПКиО_им.Маяковского
{
    public partial class Istoria_vhoda : Form
    {
        public Istoria_vhoda()
        {
            InitializeComponent();
            con = new SqlConnection(@"Data source = KYPAMA\KYPAMA; initial catalog = Прокат; Integrated security = SSPI;");
            con.Open();
            string select = @"SELECT [LastEntry],[Login],[EntryType] FROM [dbo].[Staff]";
            SqlCommand com = new SqlCommand(select, con);
            DataTable table = new DataTable();
            SqlDataReader reader = com.ExecuteReader();
            table.Load(reader);
            con.Close();
            tablitsa_istoria.DataSource = table;
        }
        SqlConnection con;
        private void obnovit_Click(object sender, EventArgs e)
        {
            con.Open();
            string select = @"SELECT [LastEntry],[Login],[EntryType] FROM [dbo].[Staff]";                        
            SqlCommand com = new SqlCommand(select, con);
            DataTable table = new DataTable();
            SqlDataReader reader = com.ExecuteReader();
            table.Load(reader);
            con.Close();
            tablitsa_istoria.DataSource = table;
        }

        private void filtr_po_loginy_TextChanged(object sender, EventArgs e)
        {
            if (filtr_po_loginy.Text != "")
            {
                con.Open();
                string select = @"SELECT [LastEntry],[Login],[EntryType] FROM [dbo].[Staff]";
                string where = "Where [Login] like '" + filtr_po_loginy.Text + "%'";
                string search = select + where;
                SqlCommand com = new SqlCommand(search, con);
                DataTable table = new DataTable();
                SqlDataReader reader = com.ExecuteReader();
                table.Load(reader);
                con.Close();
                tablitsa_istoria.DataSource = table;
            }

            //if (filtr_po_loginy.Text != "" && filtr_po_date.Text != "")
            //{
            //    con.Open();
            //    string select = @"SELECT [LastEntry],[Login],[EntryType] FROM [dbo].[Staff]";
            //    string where = "Where Login = '" + filtr_po_loginy.Text + "' and [LastEntry] = '"+ filtr_po_date.Value + "'";
            //    string search = select + where;
            //    SqlCommand com = new SqlCommand(search, con);
            //    DataTable table = new DataTable();
            //    SqlDataReader reader = com.ExecuteReader();
            //    table.Load(reader);
            //    con.Close();
            //    tablitsa_istoria.DataSource = table;
            //}

        }

        private void filtr_po_date_ValueChanged(object sender, EventArgs e)
        {
            //if (filtr_po_loginy.Text == "" && filtr_po_date.Text != "")
            //{
            //    con.Open();
            //    string select = @"SELECT [LastEntry],[Login],[EntryType] FROM [dbo].[Staff]";
            //    string where = "Where [LastEntry] = '" + filtr_po_date.Value.ToString().Replace() + "'";
            //    string search = select + where;
            //    SqlCommand com = new SqlCommand(search, con);
            //    DataTable table = new DataTable();
            //    SqlDataReader reader = com.ExecuteReader();
            //    table.Load(reader);
            //    con.Close();
            //    tablitsa_istoria.DataSource = table;
            //}
            //if (filtr_po_loginy.Text != "" && filtr_po_date.Text != "")
            //{
            //    con.Open();
            //    string select = @"SELECT [LastEntry],[Login],[EntryType] FROM [dbo].[Staff]";
            //    string where = "Where Login = '" + filtr_po_loginy.Text + "' and [LastEntry] = '" + filtr_po_date.Value + "'";
            //    string search = select + where;
            //    SqlCommand com = new SqlCommand(search, con);
            //    DataTable table = new DataTable();
            //    SqlDataReader reader = com.ExecuteReader();
            //    table.Load(reader);
            //    con.Close();
            //    tablitsa_istoria.DataSource = table;
            //}
        }
    }
}

