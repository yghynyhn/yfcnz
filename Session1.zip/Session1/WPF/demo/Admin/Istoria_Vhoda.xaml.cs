﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace demo.Admin
{
    /// <summary>
    /// Логика взаимодействия для Istoria_Vhoda.xaml
    /// </summary>
    public partial class Istoria_Vhoda : Page
    {
        public Istoria_Vhoda()
        {
            InitializeComponent();
            DGrid_Istoria.ItemsSource = Prokat.Sotrudniki.ToList();
        }
        ProkatEntities1 Prokat = new ProkatEntities1();
        private void TBox_Login_TextChanged(object sender, TextChangedEventArgs e)
        {
            DGrid_Istoria.ItemsSource = null;
            DGrid_Istoria.ItemsSource = Prokat.Sotrudniki.Where(p=> p.Login.Contains(TBox_Login.Text) || p.Posledny_vhod.Contains(TBox_Data.SelectedDate.ToString())).ToList();
        }

        private void TBox_Data_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            DGrid_Istoria.ItemsSource = null;
            DGrid_Istoria.ItemsSource = Prokat.Sotrudniki.Where(p => p.Login.Contains(TBox_Login.Text) || p.Posledny_vhod.Contains(TBox_Data.SelectedDate.ToString())).ToList();
        }
    }
}
