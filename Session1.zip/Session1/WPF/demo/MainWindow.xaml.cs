﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.IO;
namespace demo
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Terminal.Vhod = this;
            DispatcherTimer dispatcherTimer = new DispatcherTimer();
            dispatcherTimer.Interval = new TimeSpan(0,1,0);
            dispatcherTimer.IsEnabled = true;
            dispatcherTimer.Tick += DispatcherTimer_Tick;
            Btn.IsEnabled = Terminal.Un_block;
        }
        int minutes = 0;
        private void DispatcherTimer_Tick(object sender, EventArgs e)
        {
            minutes++;
            switch (minutes)
            {
                case 3:
                    if (Terminal.Un_block == false)
                    {
                        minutes = 0;
                        Terminal.Un_block = true;
                        Btn.IsEnabled = Terminal.Un_block;
                    }
                    break;
            }
        }

        ProkatEntities1 Prokat = new ProkatEntities1();
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Sotrudniki sotrudnic = Prokat.Sotrudniki.FirstOrDefault(p => p.Login == Tbox_Login.Text);
            if (sotrudnic != null)
            {
                sotrudnic.Posledny_vhod = DateTime.Now.ToShortDateString();
                if (sotrudnic.Parol == Tbox_Parol.Password)
                {
                    sotrudnic.Tip_vhoda = "Успешно";
                    Prokat.SaveChanges();
                    switch (sotrudnic.Dolznost)
                    {
                        case "Продавец":
                            Prodavec.MainProdavec main_prodavec = new Prodavec.MainProdavec();
                            main_prodavec.Show();
                            this.Hide();
                            break;
                        case "Старший продавец":
                            
                            break;
                        case "Администратор":
                            Admin.MainAdmin main_admin = new Admin.MainAdmin();
                            main_admin.Show();
                            this.Hide();
                            break;
                    }

                }
                else
                {
                    sotrudnic.Tip_vhoda = "Неуспешно";
                    MessageBox.Show("Неверный пароль!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void Voity_Click(object sender, RoutedEventArgs e)
        {
            Sotrudniki sotrudnic = Prokat.Sotrudniki.FirstOrDefault(p => p.Login == Tbox_Login.Text);
            if (sotrudnic != null)
            {
                sotrudnic.Posledny_vhod = DateTime.Now.ToShortDateString();
                if (sotrudnic.Parol == Tbox_Parol.Password)
                {
                    Terminal.Sotrudnik = sotrudnic;
                    sotrudnic.Tip_vhoda = "Успешно";
                    Prokat.SaveChanges();
                    switch (sotrudnic.Dolznost)
                    {
                        case "Продавец":
                            Prodavec.MainProdavec main_prodavec = new Prodavec.MainProdavec();
                            main_prodavec.Show();
                            this.Hide();
                            break;
                        case "Старший продавец":

                            break;
                        case "Администратор":
                            Admin.MainAdmin main_admin = new Admin.MainAdmin();
                            main_admin.Show();
                            this.Hide();
                            break;
                    }

                }
            }
        }

        private void PokazatParolCheck_Unchecked(object sender, RoutedEventArgs e)
        {
            PokazatParol.Visibility = Visibility.Collapsed;
            Tbox_Parol.Visibility = Visibility.Visible;
        }

        private void PokazatParolCheck_Checked(object sender, RoutedEventArgs e)
        {
            PokazatParol.Text = Tbox_Parol.Password;
            PokazatParol.Visibility = Visibility.Visible;
            Tbox_Parol.Visibility = Visibility.Collapsed;
        }

        private void PokazatParol_TextChanged(object sender, TextChangedEventArgs e)
        {
            Tbox_Parol.Password = PokazatParol.Text;
        }
    }
}
