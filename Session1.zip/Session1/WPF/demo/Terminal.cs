﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace demo
{
    internal static class Terminal
    {
        static public Zakazi Tekyshii_zakaz;
        static public Sotrudniki Sotrudnik;
        static public Window Vhod;
        static public bool Un_block = true;
        static public Frame Prodavec_Frame;
    }
}
