﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace demo.Prodavec
{
    /// <summary>
    /// Логика взаимодействия для Zapros.xaml
    /// </summary>
    public partial class Zapros : Page
    {
        ProkatEntities1 Prokat = new ProkatEntities1();
        public Zapros()
        {
            InitializeComponent();
            int i = Prokat.Zakazi.ToList().Last().Id;
            TBox_code.Text = (i + 1).ToString();
        }

        private void TBox_code_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                Terminal.Tekyshii_zakaz = new Zakazi();
                Terminal.Tekyshii_zakaz.Kod_zakaza = TBox_code.Text;
                Terminal.Prodavec_Frame.Navigate(new FormirovanieZakaza());

                Prokat.SaveChanges();
            }
        }
    }
}
