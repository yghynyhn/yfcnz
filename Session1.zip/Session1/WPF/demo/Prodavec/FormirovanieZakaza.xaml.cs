﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Word = Microsoft.Office.Interop.Word;

namespace demo.Prodavec
{
    /// <summary>
    /// Логика взаимодействия для FormirovanieZakaza.xaml
    /// </summary>
    public partial class FormirovanieZakaza : Page
    {
        public FormirovanieZakaza()
        {
            InitializeComponent();
            DG_Client.ItemsSource = ProkatEntities1.Client.ToList();
            DG_uslugi.ItemsSource = ProkatEntities1.Услуги.ToList();
        }

        ProkatEntities1 ProkatEntities1 = new ProkatEntities1();
        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            switch (CBox_Sort.Text)
            {
                case "Фамилия":
                    DG_Client.ItemsSource = null;
                    DG_Client.ItemsSource = ProkatEntities1.Client.Where(p => p.Familia == CBox_Sort.Text);
                    break;
                case "Имя":
                    DG_Client.ItemsSource = null;
                    DG_Client.ItemsSource = ProkatEntities1.Client.Where(p => p.Imya == CBox_Sort.Text);
                    break;
                case "Отчество":
                    DG_Client.ItemsSource = null;
                    DG_Client.ItemsSource = ProkatEntities1.Client.Where(p => p.Otchestvo == CBox_Sort.Text);
                    break;
                case "Паспортные данные":
                    DG_Client.ItemsSource = null;
                    DG_Client.ItemsSource = ProkatEntities1.Client.Where(p => p.Passport == CBox_Sort.Text);
                    break;
                case "Дата рождения":
                    DG_Client.ItemsSource = null;
                    DG_Client.ItemsSource = ProkatEntities1.Client.Where(p => p.Data_rozdenya.Year.ToString() == CBox_Sort.Text);
                    break;
                case "Адрес":
                    DG_Client.ItemsSource = null;
                    DG_Client.ItemsSource = ProkatEntities1.Client.Where(p => p.Adres == CBox_Sort.Text);
                    break;
                case "E-mail":
                    DG_Client.ItemsSource = null;
                    DG_Client.ItemsSource = ProkatEntities1.Client.Where(p => p.E_mail == CBox_Sort.Text);
                    break;
            }
        }

        private void DG_Client_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (DG_Client.SelectedItem != null)
            {
                Terminal.Tekyshii_zakaz.Client = DG_Client.SelectedItem as Client;
                MessageBox.Show("Клиент выбран!");
            }
        }
        List<Услуги> selected = new List<Услуги>();
        private void DataGrid_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (DG_uslugi.SelectedItem != null)
            {
                selected.Add(DG_uslugi.SelectedItem as Услуги);
                LView_Selected_Uslugi.ItemsSource = null;
                LView_Selected_Uslugi.ItemsSource = selected;
            }
        }
        ProkatEntities1 Prokat = new ProkatEntities1();
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            ProkatEntities1.Zakazi.Add(Terminal.Tekyshii_zakaz);
            ProkatEntities1.SaveChanges();
            foreach (var item in selected)
            {
                Terminal.Tekyshii_zakaz.Spisok_uslug_zakaz.Add(new Spisok_uslug_zakaz() { Услуги = item, Zakazi = ProkatEntities1.Zakazi.Last() });
            }
            Prokat.SaveChanges();
            ElectronDoc();
            ElectronRefer();
            Terminal.Prodavec_Frame.Navigate(new Zapros());
        }


        /// <summary>
        /// Данный метод создаёт ссылку на электронную версию документа
        /// </summary>
        void ElectronRefer()
        {
            string dir2 = new FileInfo(@"Документы\Электронный документ.docx").FullName;
            string dir1 = new DirectoryInfo(@"Документы").FullName;
            byte[] toEncodeAsBytes = System.Text.ASCIIEncoding.ASCII.GetBytes("Дата_заказа=" + Terminal.Tekyshii_zakaz.Data_sozdania.ToLongDateString() + "&номер_заказа=" + Terminal.Tekyshii_zakaz.Kod_zakaza);
            string returnValue = System.Convert.ToBase64String(toEncodeAsBytes);
            File.WriteAllText(dir1 + "/Ссылка.txt", $"https://wsrussia.ru/?data=base64({returnValue})");

        }

        /// <summary>
        /// Данный метод создаёт электронный документ
        /// </summary>
        void ElectronDoc()
        {
            string dir2 = new FileInfo(@"Документы\Электронный документ.docx").FullName;
            string dir1 = new DirectoryInfo(@"Документы").FullName;
            string ПереченьУслуг = "";
            int sum = 0;
            foreach (var item in Terminal.Tekyshii_zakaz.Spisok_uslug_zakaz)
            {
                ПереченьУслуг += item.Услуги.Naimenovanie_uslugi + ", ";
                sum += item.Услуги.Stoimost;
            }
            Word.Application app = new Word.Application();
            File.Copy(dir2, dir1 + @"\Электронный документ" + "_copy.docx");
            Word.Document doc = null;
            doc = app.Documents.Open(dir1 + @"\Электронный документ" + "_copy.docx");
            doc.Activate();
            Word.Bookmarks wBookmarks = doc.Bookmarks;
            doc.Bookmarks["Адрес"].Range.Text = Terminal.Tekyshii_zakaz.Client.Adres;
            doc.Bookmarks["Дата"].Range.Text = Terminal.Tekyshii_zakaz.Data_sozdania.ToShortDateString();
            doc.Bookmarks["Код"].Range.Text = Terminal.Tekyshii_zakaz.Kod_zakaza;
            doc.Bookmarks["Номер"].Range.Text = Terminal.Tekyshii_zakaz.Id.ToString();
            doc.Bookmarks["Перечень"].Range.Text = ПереченьУслуг;
            doc.Bookmarks["Стоимость"].Range.Text = sum.ToString();
            doc.Bookmarks["ФИО"].Range.Text = Terminal.Tekyshii_zakaz.Client.Familia + " " + Terminal.Tekyshii_zakaz.Client.Imya + " " + Terminal.Tekyshii_zakaz.Client.Otchestvo;
            doc.Close();
            doc = null;
            Process.Start(dir1 + @"\Электронный документ" + "_copy.docx");
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            (new AddClient()).ShowDialog();
            DG_Client.ItemsSource = null;
            DG_Client.ItemsSource = ProkatEntities1.Client.ToList();
        }
    }
}
