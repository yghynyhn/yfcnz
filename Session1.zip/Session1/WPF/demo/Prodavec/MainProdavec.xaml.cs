﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace demo.Prodavec
{
    /// <summary>
    /// Логика взаимодействия для MainProdavec.xaml
    /// </summary>
    public partial class MainProdavec : Window
    {
        public MainProdavec()
        {
            InitializeComponent();
            Terminal.Prodavec_Frame = ProdavecFrame;
            this.DataContext = Terminal.Sotrudnik;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            ProdavecFrame.Navigate(new Zapros());
        }

        private void Vihod_Click(object sender, RoutedEventArgs e)
        {
            MainWindow avtorization = new MainWindow();
            avtorization.Show();
            Close();
        }
    }
}
